import json
import re

import google.generativeai as genai
import streamlit as st

st.set_page_config(
    page_title="AI 냉장고 파먹기: 영수증 레시피 추천",
    page_icon="🧑‍🍳",
    layout="wide",
)


def configure_gemini(api_key: str) -> bool:
    try:
        genai.configure(api_key=api_key)
        return True
    except Exception as exc:
        st.error(f"Gemini 설정에 실패했습니다: {exc}")
        return False


def extract_json(text: str):
    if not text:
        return None
    fence = re.search(r"```(?:json)?\s*(\{.*?\}|\[.*?\])\s*```", text, re.DOTALL)
    if fence:
        candidate = fence.group(1)
    else:
        match = re.search(r"(\{.*\}|\[.*\])", text, re.DOTALL)
        candidate = match.group(1) if match else text
    try:
        return json.loads(candidate)
    except json.JSONDecodeError:
        return None


def parse_ingredients(raw_text: str) -> list[str]:
    if not raw_text:
        return []
    tokens = re.split(r"[,\n;·•\t]+", raw_text)
    cleaned: list[str] = []
    seen: set[str] = set()
    for token in tokens:
        name = token.strip()
        name = re.sub(r"^\s*[-*\d\.\)]+\s*", "", name)
        name = re.sub(r"\s+\d+([.,]\d+)?\s*(개|봉|팩|g|kg|ml|L|장|병|박스|입)?\s*$", "", name)
        name = name.strip()
        if name and name not in seen:
            seen.add(name)
            cleaned.append(name)
    return cleaned


def normalize_ingredients_with_ai(items: list[str]) -> list[str]:
    if not items:
        return []
    model = genai.GenerativeModel("gemini-1.5-flash")
    joined = ", ".join(items)
    prompt = (
        "당신은 한국 마트/편의점 영수증을 분석하는 전문가입니다.\n"
        f"다음은 사용자가 직접 입력한 영수증 항목입니다: {joined}\n"
        "여기서 '식재료(요리에 쓸 수 있는 음식 재료)'만 추려, 한국어 표준 명칭으로 정리해 주세요.\n"
        "휴지, 세제, 봉투, 결제 정보 같은 비식품 항목은 제외하세요.\n"
        "브랜드명/수량/단위는 제거하고 재료 이름만 남깁니다 (예: 'CJ 백설 식용유 500ml' → '식용유').\n"
        "반드시 아래 JSON 형식으로만 답변하세요. 다른 설명은 절대 포함하지 마세요.\n"
        '{ "ingredients": ["계란", "양파", "대파"] }'
    )
    response = model.generate_content(prompt)
    data = extract_json(response.text or "")
    if isinstance(data, dict) and isinstance(data.get("ingredients"), list):
        cleaned: list[str] = []
        seen: set[str] = set()
        for item in data["ingredients"]:
            if not isinstance(item, str):
                continue
            name = item.strip()
            if name and name not in seen:
                seen.add(name)
                cleaned.append(name)
        return cleaned
    return items


def recommend_recipes(ingredients: list[str]):
    model = genai.GenerativeModel("gemini-1.5-flash")
    joined = ", ".join(ingredients)
    prompt = (
        "당신은 자취생을 위한 친절한 한국 요리 셰프입니다.\n"
        f"다음 식재료로 만들 수 있는 '자취생도 할 수 있는 간단한 레시피' 3가지를 추천해 주세요: {joined}.\n"
        "기본 양념(소금, 후추, 간장, 식용유, 설탕 등)은 가지고 있다고 가정합니다.\n"
        "반드시 아래 JSON 형식으로만 답변하세요. 추가 설명은 금지합니다.\n"
        "{\n"
        '  "recipes": [\n'
        "    {\n"
        '      "title": "요리 이름",\n'
        '      "cooking_time": "약 15분",\n'
        '      "difficulty": 2,\n'
        '      "ingredients": ["재료1 1개", "재료2 100g"],\n'
        '      "steps": ["1단계 설명", "2단계 설명", "3단계 설명"]\n'
        "    }\n"
        "  ]\n"
        "}\n"
        "difficulty는 1~5 사이의 정수(별점)이며 숫자가 클수록 어렵습니다."
    )
    response = model.generate_content(prompt)
    data = extract_json(response.text or "")
    if isinstance(data, dict) and isinstance(data.get("recipes"), list):
        return data["recipes"]
    return []


def render_tags(items: list[str]):
    palette = [
        ("#FFE4E1", "#C2185B"),
        ("#E3F2FD", "#1565C0"),
        ("#E8F5E9", "#2E7D32"),
        ("#FFF3E0", "#E65100"),
        ("#F3E5F5", "#6A1B9A"),
        ("#E0F7FA", "#00838F"),
    ]
    chips = []
    for idx, item in enumerate(items):
        bg, fg = palette[idx % len(palette)]
        chips.append(
            f'<span style="display:inline-block;background:{bg};color:{fg};'
            f"padding:6px 14px;border-radius:999px;margin:4px 6px 4px 0;"
            f'font-size:14px;font-weight:600;border:1px solid {fg}22;">'
            f"🥕 {item}</span>"
        )
    st.markdown("<div>" + "".join(chips) + "</div>", unsafe_allow_html=True)


def difficulty_stars(level) -> str:
    try:
        n = max(1, min(5, int(level)))
    except (TypeError, ValueError):
        n = 1
    return "⭐" * n + "☆" * (5 - n)


def render_recipes(recipes: list[dict]):
    for idx, recipe in enumerate(recipes, start=1):
        title = recipe.get("title", f"레시피 {idx}")
        cooking_time = recipe.get("cooking_time", "정보 없음")
        difficulty = recipe.get("difficulty", 1)
        ing = recipe.get("ingredients", []) or []
        steps = recipe.get("steps", []) or []
        with st.expander(f"🍳 {idx}. {title}", expanded=(idx == 1)):
            cols = st.columns(2)
            cols[0].markdown(f"**⏱️ 예상 조리 시간**\n\n{cooking_time}")
            cols[1].markdown(f"**🌟 난이도**\n\n{difficulty_stars(difficulty)}")
            st.markdown("---")
            st.markdown("**📋 필요한 재료**")
            if ing:
                st.markdown("\n".join(f"- {item}" for item in ing))
            else:
                st.caption("재료 정보가 없습니다.")
            st.markdown("**👩‍🍳 조리 순서**")
            if steps:
                for step_idx, step in enumerate(steps, start=1):
                    clean = re.sub(r"^\s*\d+[\.\)]\s*", "", str(step))
                    st.markdown(f"**{step_idx}.** {clean}")
            else:
                st.caption("조리 순서가 제공되지 않았습니다.")


def main():
    st.title("🧑‍🍳 AI 냉장고 파먹기: 영수증 레시피 추천")
    st.caption(
        "영수증 항목을 직접 입력하면 AI가 식재료를 정리하고 자취생용 간단 레시피 3가지를 추천해 드려요."
    )

    with st.sidebar:
        st.header("⚙️ 설정")
        st.markdown(
            "**Google Gemini API Key**\n\n"
            "👉 [API Key 발급받기](https://aistudio.google.com/app/apikey)"
        )
        api_key = st.text_input(
            "API Key를 입력하세요",
            type="password",
            placeholder="AIza...",
            help="입력한 Key는 세션 동안만 사용되며 저장되지 않습니다.",
        )
        st.markdown("---")
        st.markdown("### 📖 사용 방법")
        st.markdown(
            "1. Gemini API Key 입력\n"
            "2. 영수증 항목을 줄바꿈 또는 콤마로 구분해 입력\n"
            "3. **레시피 추천 받기** 클릭\n"
            "4. 추천 레시피 확인!"
        )

    st.subheader("📝 영수증 항목 입력")
    st.markdown(
        "영수증에 적힌 품목을 **한 줄에 하나씩** 또는 **콤마(,)** 로 구분해 입력해 주세요."
    )

    example_text = "계란 10구\n대파 1단\n양파 3개\n돼지고기 앞다리살 300g\n두부 1모\n식용유 500ml"

    if "receipt_text" not in st.session_state:
        st.session_state["receipt_text"] = ""

    btn_cols = st.columns([1, 1, 6])
    with btn_cols[0]:
        if st.button("📋 예시 채우기", use_container_width=True):
            st.session_state["receipt_text"] = example_text
            st.rerun()
    with btn_cols[1]:
        if st.button("🧹 비우기", use_container_width=True):
            st.session_state["receipt_text"] = ""
            st.rerun()

    raw_text = st.text_area(
        "영수증 항목",
        key="receipt_text",
        height=220,
        placeholder=example_text,
    )

    parsed_preview = parse_ingredients(raw_text)
    if parsed_preview:
        st.caption(f"✅ {len(parsed_preview)}개의 항목이 인식되었어요. 미리보기:")
        render_tags(parsed_preview)
        st.markdown("")

    run = st.button(
        "🔍 레시피 추천 받기",
        type="primary",
        use_container_width=True,
        disabled=not (api_key and parsed_preview),
    )

    if not api_key:
        st.warning("좌측 사이드바에 Gemini API Key를 먼저 입력해 주세요.")
    elif not parsed_preview:
        st.info("영수증 항목을 한 개 이상 입력해 주세요.")

    if run and api_key and parsed_preview:
        if not configure_gemini(api_key):
            return

        with st.spinner("🤖 입력하신 항목에서 식재료를 정리하는 중..."):
            try:
                ingredients = normalize_ingredients_with_ai(parsed_preview)
            except Exception as exc:
                st.error(
                    "식재료 정리 중 오류가 발생했습니다. API Key 또는 입력 내용을 다시 확인해 주세요.\n\n"
                    f"세부 정보: {exc}"
                )
                return

        if not ingredients:
            st.warning(
                "입력하신 항목에서 식재료를 찾지 못했습니다. 다시 입력해 주세요."
            )
            return

        st.markdown("## 🥗 인식된 식재료")
        render_tags(ingredients)
        st.markdown("")

        with st.spinner("🍽️ 자취생 맞춤 레시피를 만들고 있어요..."):
            try:
                recipes = recommend_recipes(ingredients)
            except Exception as exc:
                st.error(
                    "레시피 생성 중 오류가 발생했습니다. 잠시 후 다시 시도해 주세요.\n\n"
                    f"세부 정보: {exc}"
                )
                return

        if not recipes:
            st.warning("레시피를 생성하지 못했습니다. 다시 시도해 주세요.")
            return

        st.markdown("## 🍱 추천 레시피 TOP 3")
        render_recipes(recipes[:3])
        st.success("맛있게 드세요! 🥢")


if __name__ == "__main__":
    main()
